import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public final class Main {
    private static final ReentrantLock stateLock = new ReentrantLock();
    private static final ReentrantLock printLock = new ReentrantLock();
    private static final Condition readyForCountdown = stateLock.newCondition();

    private static boolean canCountDown = false;
    private static int sharedCounter = 0;

    private Main() {
        // Utility class.
    }

    private static void safePrint(String message) {
        printLock.lock();
        try {
            System.out.println(message);
        } finally {
            printLock.unlock();
        }
    }

    private static void countUpToTwenty() {
        for (int i = 0; i <= 20; i++) {
            stateLock.lock();
            try {
                sharedCounter = i;
            } finally {
                stateLock.unlock();
            }

            safePrint("Thread 1 (count up): " + i);
            sleepBriefly(120);
        }

        stateLock.lock();
        try {
            canCountDown = true;
            readyForCountdown.signal();
        } finally {
            stateLock.unlock();
        }
    }

    private static void countDownToZero() {
        stateLock.lock();
        try {
            while (!canCountDown) {
                try {
                    readyForCountdown.await();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    safePrint("Thread 2 interrupted while waiting.");
                    return;
                }
            }
        } finally {
            stateLock.unlock();
        }

        for (int i = 20; i >= 0; i--) {
            stateLock.lock();
            try {
                sharedCounter = i;
            } finally {
                stateLock.unlock();
            }

            safePrint("Thread 2 (count down): " + i);
            sleepBriefly(120);
        }
    }

    private static void sleepBriefly(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    public static void main(String[] args) {
        safePrint("Starting Java counter program...");

        Thread upThread = new Thread(Main::countUpToTwenty, "counter-up");
        Thread downThread = new Thread(Main::countDownToZero, "counter-down");

        upThread.start();
        downThread.start();

        try {
            upThread.join();
            downThread.join();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            safePrint("Main thread interrupted while waiting.");
            return;
        }

        int finalValue;
        stateLock.lock();
        try {
            finalValue = sharedCounter;
        } finally {
            stateLock.unlock();
        }

        safePrint("Final shared counter value: " + finalValue);
        safePrint("Program complete.");
    }
}
